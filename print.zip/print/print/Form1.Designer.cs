﻿namespace print
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.打印预览 = new System.Windows.Forms.Button();
            this.取打印图 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.打印设置 = new System.Windows.Forms.Button();
            this.页面设置 = new System.Windows.Forms.Button();
            this.打印 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // 打印预览
            // 
            this.打印预览.Location = new System.Drawing.Point(732, 12);
            this.打印预览.Name = "打印预览";
            this.打印预览.Size = new System.Drawing.Size(75, 23);
            this.打印预览.TabIndex = 0;
            this.打印预览.Text = "打印预览";
            this.打印预览.UseVisualStyleBackColor = true;
            this.打印预览.Click += new System.EventHandler(this.button1_Click);
            // 
            // 取打印图
            // 
            this.取打印图.Location = new System.Drawing.Point(732, 51);
            this.取打印图.Name = "取打印图";
            this.取打印图.Size = new System.Drawing.Size(75, 23);
            this.取打印图.TabIndex = 1;
            this.取打印图.Text = "取打印图";
            this.取打印图.UseVisualStyleBackColor = true;
            this.取打印图.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(475, 451);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // 打印设置
            // 
            this.打印设置.Location = new System.Drawing.Point(732, 90);
            this.打印设置.Name = "打印设置";
            this.打印设置.Size = new System.Drawing.Size(75, 23);
            this.打印设置.TabIndex = 3;
            this.打印设置.Text = "打印设置";
            this.打印设置.UseVisualStyleBackColor = true;
            this.打印设置.Click += new System.EventHandler(this.button3_Click);
            // 
            // 页面设置
            // 
            this.页面设置.Location = new System.Drawing.Point(732, 134);
            this.页面设置.Name = "页面设置";
            this.页面设置.Size = new System.Drawing.Size(75, 23);
            this.页面设置.TabIndex = 4;
            this.页面设置.Text = "页面设置";
            this.页面设置.UseVisualStyleBackColor = true;
            this.页面设置.Click += new System.EventHandler(this.页面设置_Click);
            // 
            // 打印
            // 
            this.打印.Location = new System.Drawing.Point(732, 179);
            this.打印.Name = "打印";
            this.打印.Size = new System.Drawing.Size(75, 21);
            this.打印.TabIndex = 5;
            this.打印.Text = "打印";
            this.打印.UseVisualStyleBackColor = true;
            this.打印.Click += new System.EventHandler(this.打印_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 475);
            this.Controls.Add(this.打印);
            this.Controls.Add(this.页面设置);
            this.Controls.Add(this.打印设置);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.取打印图);
            this.Controls.Add(this.打印预览);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button 打印预览;
        private System.Windows.Forms.Button 取打印图;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.Button 打印设置;
        private System.Windows.Forms.Button 页面设置;
        private System.Windows.Forms.Button 打印;
    }
}

