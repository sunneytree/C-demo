﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace print
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        PrintDocument printDocument;
        private void Form1_Load(object sender, EventArgs e)
        {
            printDocument = new PrintDocument();
            printDocument.PrintPage += new PrintPageEventHandler(printDocument_PrintPage);

        }
        void printDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
           
            SolidBrush blueBrush = new SolidBrush(Color.White);

            // Create rectangle.
            Rectangle rect = new Rectangle(0, 0, 200, 200);

            // Fill rectangle to screen.
            e.Graphics.FillRectangle(blueBrush, rect);


            e.Graphics.DrawRectangle(new Pen(Brushes.Red, 2), 0, 0, 100, 100);
            e.Graphics.DrawString("ddddddddddddddddddddd", new Font("宋体", 16), Brushes.Blue, new PointF(100, 100));

            // Create solid brush.


        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog printPreviewDialog1 = new PrintPreviewDialog();
            printPreviewDialog1.Document = printDocument;
            printPreviewDialog1.ShowDialog();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            PreviewPrintController previewController = new PreviewPrintController();


            previewController.UseAntiAlias = true;
            printDocument.PrintController = previewController;//赋值后，为打印预览模式，printDocument.Print() 不执行打印操作，执行预览操作


            printDocument.Print();
            PreviewPageInfo[] pageInfo = previewController.GetPreviewPageInfo();
            if(pageInfo !=null && pageInfo.Length>0)
            {
                Image image = pageInfo[0].Image;
                Size s = pageInfo[0].PhysicalSize;
                Bitmap bitmap = new Bitmap(image, s.Width, s.Height);

                this.pictureBox1.BackColor = Color.Yellow;
                this.pictureBox1.Image = (Image)bitmap;
            }
        }

       

        private void button3_Click(object sender, EventArgs e)//打印设置对话框
        {
            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDocument;
            printDialog.ShowDialog();

        }

        private void 页面设置_Click(object sender, EventArgs e)
        {
            PageSetupDialog pageSetupDialog = new PageSetupDialog();
            pageSetupDialog.Document = printDocument;
            pageSetupDialog.ShowDialog();
        }

        private void 打印_Click(object sender, EventArgs e)
        {

            printDocument.Print();


            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDocument;
            //lineReader = new StringReader(textBox.Text);
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // printDocument.Print();
                }
                catch (Exception excep)
                {
                    MessageBox.Show(excep.Message, "打印出错", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    printDocument.PrintController.OnEndPrint(printDocument, new PrintEventArgs());
                }
            }
        }






    }
}
